/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appprovatest;

import classes.Start;
import classes.Verificar;
import componentes.Atividade;
import componentes.CondicaoZero;
import componentes.Usuario;
import componentes.Simulado;
import componentes.Perfil;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author Douglas
 */
public class AppProvaTest {

    /**
     * @param args the command line arguments
     */
    public static void mainOLD(String[] args) {
        
        /*
        //int r = new (int)(Random());
        int r = (int) (Math.random() * 1000);

        WebDriver driver = Start.myDriver("http://mobile.stg.appprova.com.br/users/sign_in");
        
        Usuario.cadastrar(driver, "Mario da Silva", "mario"+r+"@gmail.com", "teste123456");
        Simulado.Iniciar(driver, "teste");
        Perfil.Preencher(driver, "Minas Gerais", "Belo Horizonte",
                "Escola Santo Tomás de Aquino", "EAD");
        Simulado.Iniciar(driver, "teste");
        Atividade.Iniciar(driver, "teste");
        CondicaoZero.Voltar(driver);
*/    
    }
    
}
