Para executar este projeto, coloque os casos de teste no método testeLab
da classe Root como no exemplo abaixo e mande executar com JUnit.
    public void testeLab() {
        CasoTesteProfessor.run();
        CasoTesteAluno.run();
    }
